CrystalClouds Python Full
========================

This is a full-featured template for CrystalClouds bot in Python.
Features included (implemented minimally):
- Moderation: ban, kick, mute, unmute, warn (sqlite3), clear messages
- Fun: joke, hug, slap, 8ball
- Utility: ping, help, userinfo, serverinfo, avatar
- Music: play, pause, resume, skip, stop, queue (uses yt-dlp + ffmpeg)
- Welcome & autorole: welcome embed, autorole assignment
- Logging: joins/leaves/commands to logs channel

Quick start:
1. Install dependencies:
   python3 -m pip install -r requirements.txt
2. Install ffmpeg (required for music):
   sudo apt install ffmpeg -y
3. Copy .env.example to .env and fill values
4. Run: python3 bot.py
