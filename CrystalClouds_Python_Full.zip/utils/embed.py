import discord, os
def fancy(title='', description='', color=None):
    color = int(os.getenv('EMBED_COLOR', '0x00FFFF'), 16) if color is None else color
    e = discord.Embed(title=title, description=description, color=color)
    e.set_footer(text='crystalclouds • 2025')
    return e
