import discord, os
from discord.ext import commands
from utils.embed import fancy

class Utility(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def ping(self, ctx):
        await ctx.send(embed=fancy(title='🏓 Pong!', description=f'Latency: {round(self.bot.latency*1000)}ms'))

    @commands.command()
    async def avatar(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        await ctx.send(embed=fancy(title=f"{member.display_name}'s avatar", description=member.display_avatar.url))

    @commands.command()
    async def serverinfo(self, ctx):
        g = ctx.guild
        desc = f'Server: {g.name}\nMembers: {g.member_count}\nID: {g.id}'
        await ctx.send(embed=fancy(title='Server Info', description=desc))

    @commands.command()
    async def userinfo(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        desc = f'User: {member}\nID: {member.id}\nCreated: {member.created_at}'
        await ctx.send(embed=fancy(title='User Info', description=desc))

async def setup(bot):
    await bot.add_cog(Utility(bot))
