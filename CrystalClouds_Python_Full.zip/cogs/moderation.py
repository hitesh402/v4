import discord, sqlite3, os, datetime
from discord.ext import commands
from utils.embed import fancy

DB = 'data/crystal.db'

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='ban')
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member, *, reason: str = 'No reason provided'):
        await member.ban(reason=reason)
        await ctx.send(embed=fancy(title='Banned', description=f'{member} was banned. Reason: {reason}'))

    @commands.command(name='kick')
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, reason: str = 'No reason provided'):
        await member.kick(reason=reason)
        await ctx.send(embed=fancy(title='Kicked', description=f'{member} was kicked. Reason: {reason}'))

    @commands.command(name='mute')
    @commands.has_permissions(manage_roles=True)
    async def mute(self, ctx, member: discord.Member, *, reason: str = 'No reason'):
        guild = ctx.guild
        role = discord.utils.get(guild.roles, name='Muted')
        if not role:
            role = await guild.create_role(name='Muted')
            for ch in guild.channels:
                try:
                    await ch.set_permissions(role, send_messages=False, speak=False)
                except: pass
        await member.add_roles(role)
        await ctx.send(embed=fancy(title='Muted', description=f'{member} muted. Reason: {reason}'))

    @commands.command(name='unmute')
    @commands.has_permissions(manage_roles=True)
    async def unmute(self, ctx, member: discord.Member):
        role = discord.utils.get(ctx.guild.roles, name='Muted')
        if role in member.roles:
            await member.remove_roles(role)
            await ctx.send(embed=fancy(title='Unmuted', description=f'{member} unmuted.'))
        else:
            await ctx.send(embed=fancy(title='Unmute', description='Member is not muted.'))

    @commands.command(name='warn')
    @commands.has_permissions(manage_messages=True)
    async def warn(self, ctx, member: discord.Member, *, reason: str = 'No reason'):
        conn = sqlite3.connect(DB)
        cur = conn.cursor()
        cur.execute('INSERT INTO warns (guild_id, user_id, moderator_id, reason, created_at) VALUES (?,?,?,?,?)',
                    (ctx.guild.id, member.id, ctx.author.id, reason, datetime.datetime.utcnow().isoformat()))
        conn.commit()
        conn.close()
        await ctx.send(embed=fancy(title='Warned', description=f'{member} was warned. Reason: {reason}'))

    @commands.command(name='warnings')
    async def warnings(self, ctx, member: discord.Member = None):
        target = member or ctx.author
        conn = sqlite3.connect(DB)
        cur = conn.cursor()
        cur.execute('SELECT id, reason, created_at, moderator_id FROM warns WHERE guild_id=? AND user_id=?', (ctx.guild.id, target.id))
        rows = cur.fetchall()
        conn.close()
        if not rows:
            await ctx.send(embed=fancy(title='Warnings', description=f'No warnings for {target}.'))
            return
        desc = ''
        for r in rows:
            desc += f'ID: {r[0]} — {r[1]} — {r[2]}\n'
        await ctx.send(embed=fancy(title=f'Warnings for {target}', description=desc))

async def setup(bot):
    await bot.add_cog(Moderation(bot))
