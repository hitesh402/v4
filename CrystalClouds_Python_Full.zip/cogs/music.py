import os, asyncio, yt_dlp, functools, aiohttp
from discord.ext import commands
from discord import FFmpegPCMAudio
from utils.embed import fancy

YTDL_OPTS = {'format': 'bestaudio/best', 'noplaylist': True}
FFMPEG_OPTS = {'options': '-vn'}

class Music(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.queues = {}  # guild_id -> [urls]

    async def ensure_voice(self, ctx):
        if ctx.author.voice is None:
            await ctx.send(embed=fancy(title='Not connected', description='You are not connected to a voice channel.'))
            return None
        return ctx.author.voice.channel

    @commands.command()
    async def play(self, ctx, *, query: str):
        channel = await self.ensure_voice(ctx)
        if not channel: return
        guild_id = ctx.guild.id
        if guild_id not in self.queues:
            self.queues[guild_id] = []
        # try to get direct url via yt-dlp
        ytdl = yt_dlp.YoutubeDL(YTDL_OPTS)
        info = ytdl.extract_info(query, download=False)
        url = info['url']
        title = info.get('title', 'Unknown')
        self.queues[guild_id].append({'url': url, 'title': title})
        await ctx.send(embed=fancy(title='Queued', description=title))
        # if not playing, connect and start
        if ctx.voice_client is None or not ctx.voice_client.is_connected():
            vc = await channel.connect()
        else:
            vc = ctx.voice_client
        if not vc.is_playing():
            await self.start_playing(ctx, vc, guild_id)

    async def start_playing(self, ctx, vc, guild_id):
        queue = self.queues.get(guild_id, [])
        if not queue:
            return
        track = queue.pop(0)
        source = FFmpegPCMAudio(track['url'], **FFMPEG_OPTS)
        vc.play(source)
        await ctx.send(embed=fancy(title='Now Playing', description=track['title']))
        while vc.is_playing() or vc.is_paused():
            await asyncio.sleep(1)
        # when finished, play next
        await asyncio.sleep(1)
        if self.queues.get(guild_id):
            await self.start_playing(ctx, vc, guild_id)

    @commands.command()
    async def skip(self, ctx):
        if ctx.voice_client and ctx.voice_client.is_playing():
            ctx.voice_client.stop()
            await ctx.send(embed=fancy(title='Skipped', description='Track skipped.'))
        else:
            await ctx.send(embed=fancy(title='Skip', description='Nothing is playing.'))

    @commands.command()
    async def stop(self, ctx):
        if ctx.voice_client and ctx.voice_client.is_connected():
            await ctx.voice_client.disconnect()
            self.queues.pop(ctx.guild.id, None)
            await ctx.send(embed=fancy(title='Stopped', description='Playback stopped and queue cleared.'))

async def setup(bot):
    await bot.add_cog(Music(bot))
