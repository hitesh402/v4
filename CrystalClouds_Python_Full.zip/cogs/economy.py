from discord.ext import commands
from utils.embed import fancy

class Economy(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.balances = {}

    @commands.command()
    async def balance(self, ctx, member: commands.MemberConverter = None):
        member = member or ctx.author
        bal = self.balances.get(member.id, 0)
        await ctx.send(embed=fancy(title='Balance', description=f'{member.mention} has {bal} coins'))

    @commands.command()
    async def work(self, ctx):
        self.balances[ctx.author.id] = self.balances.get(ctx.author.id, 0) + 50
        await ctx.send(embed=fancy(title='Work', description='You earned 50 coins!'))

async def setup(bot):
    await bot.add_cog(Economy(bot))
