import random
from discord.ext import commands
from utils.embed import fancy

class Fun(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def joke(self, ctx):
        jokes = ['Why do programmers prefer dark mode? Because light attracts bugs!', 'Why did the developer go broke? Because he used up all his cache.']
        await ctx.send(embed=fancy(title='Joke', description=random.choice(jokes)))

    @commands.command()
    async def hug(self, ctx, member: commands.MemberConverter = None):
        member = member or ctx.author
        await ctx.send(embed=fancy(title='Hug', description=f'{ctx.author.mention} hugged {member.mention} 🤗'))

    @commands.command()
    async def slap(self, ctx, member: commands.MemberConverter = None):
        member = member or ctx.author
        await ctx.send(embed=fancy(title='Slap', description=f'{ctx.author.mention} slapped {member.mention} 😳'))

    @commands.command(name='8ball')
    async def eightball(self, ctx, *, question: str = None):
        answers = ['Yes', 'No', 'Maybe', 'Ask later']
        await ctx.send(embed=fancy(title='8ball', description=random.choice(answers)))

async def setup(bot):
    await bot.add_cog(Fun(bot))
