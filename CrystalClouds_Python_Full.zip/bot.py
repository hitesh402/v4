import os, discord, asyncio
from discord.ext import commands
from dotenv import load_dotenv
import sqlite3

load_dotenv()
TOKEN = os.getenv('DISCORD_TOKEN')
PREFIX = os.getenv('PREFIX', '!')
GUILD_ID = os.getenv('GUILD_ID')

intents = discord.Intents.all()
bot = commands.Bot(command_prefix=PREFIX, intents=intents)
bot.remove_command('help')

# ensure data folder and sqlite DB
os.makedirs('data', exist_ok=True)
db_path = 'data/crystal.db'
conn = sqlite3.connect(db_path)
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS warns (id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER, user_id INTEGER, moderator_id INTEGER, reason TEXT, created_at TEXT)''')
conn.commit()
conn.close()

COGS = ['cogs.welcome', 'cogs.moderation', 'cogs.fun', 'cogs.utility', 'cogs.music', 'cogs.economy']

@bot.event
async def on_ready():
    print(f'✅ Logged in as {bot.user} (ID: {bot.user.id})')
    for cog in COGS:
        try:
            await bot.load_extension(cog)
            print('Loaded', cog)
        except Exception as e:
            print('Error loading', cog, e)
    # sync app commands optionally per guild for faster testing
    try:
        if GUILD_ID:
            await bot.tree.sync(guild=discord.Object(id=int(GUILD_ID)))
            print('Synced commands to guild', GUILD_ID)
        else:
            await bot.tree.sync()
            print('Synced global commands')
    except Exception as e:
        print('Sync error:', e)

if __name__ == '__main__':
    bot.run(TOKEN)
