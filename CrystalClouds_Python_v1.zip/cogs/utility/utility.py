import discord
from discord import app_commands
from discord.ext import commands
from utils.embed_helper import fancy_embed

class UtilityCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

@app_commands.command(name='ping', description='Crystal Clouds command: ping')
async def ping(self, interaction: discord.Interaction):
    """Auto-generated template for ping"""
    embed = fancy_embed(title='/ping', description='This is a template response for ping. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='help', description='Crystal Clouds command: help')
async def help(self, interaction: discord.Interaction):
    """Auto-generated template for help"""
    embed = fancy_embed(title='/help', description='This is a template response for help. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='userinfo', description='Crystal Clouds command: userinfo')
async def userinfo(self, interaction: discord.Interaction, member: discord.Member = None):
    """Auto-generated template for userinfo"""
    embed = fancy_embed(title='/userinfo', description='This is a template response for userinfo. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='serverinfo', description='Crystal Clouds command: serverinfo')
async def serverinfo(self, interaction: discord.Interaction):
    """Auto-generated template for serverinfo"""
    embed = fancy_embed(title='/serverinfo', description='This is a template response for serverinfo. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='avatar', description='Crystal Clouds command: avatar')
async def avatar(self, interaction: discord.Interaction, member: discord.Member = None):
    """Auto-generated template for avatar"""
    embed = fancy_embed(title='/avatar', description='This is a template response for avatar. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='roleinfo', description='Crystal Clouds command: roleinfo')
async def roleinfo(self, interaction: discord.Interaction, member: discord.Member = None):
    """Auto-generated template for roleinfo"""
    embed = fancy_embed(title='/roleinfo', description='This is a template response for roleinfo. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='invite', description='Crystal Clouds command: invite')
async def invite(self, interaction: discord.Interaction):
    """Auto-generated template for invite"""
    embed = fancy_embed(title='/invite', description='This is a template response for invite. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='botinfo', description='Crystal Clouds command: botinfo')
async def botinfo(self, interaction: discord.Interaction):
    """Auto-generated template for botinfo"""
    embed = fancy_embed(title='/botinfo', description='This is a template response for botinfo. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='stats', description='Crystal Clouds command: stats')
async def stats(self, interaction: discord.Interaction):
    """Auto-generated template for stats"""
    embed = fancy_embed(title='/stats', description='This is a template response for stats. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='uptime', description='Crystal Clouds command: uptime')
async def uptime(self, interaction: discord.Interaction):
    """Auto-generated template for uptime"""
    embed = fancy_embed(title='/uptime', description='This is a template response for uptime. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='servercount', description='Crystal Clouds command: servercount')
async def servercount(self, interaction: discord.Interaction):
    """Auto-generated template for servercount"""
    embed = fancy_embed(title='/servercount', description='This is a template response for servercount. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='support', description='Crystal Clouds command: support')
async def support(self, interaction: discord.Interaction):
    """Auto-generated template for support"""
    embed = fancy_embed(title='/support', description='This is a template response for support. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='pingweb', description='Crystal Clouds command: pingweb')
async def pingweb(self, interaction: discord.Interaction):
    """Auto-generated template for pingweb"""
    embed = fancy_embed(title='/pingweb', description='This is a template response for pingweb. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='github', description='Crystal Clouds command: github')
async def github(self, interaction: discord.Interaction):
    """Auto-generated template for github"""
    embed = fancy_embed(title='/github', description='This is a template response for github. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='vote', description='Crystal Clouds command: vote')
async def vote(self, interaction: discord.Interaction):
    """Auto-generated template for vote"""
    embed = fancy_embed(title='/vote', description='This is a template response for vote. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='color', description='Crystal Clouds command: color')
async def color(self, interaction: discord.Interaction):
    """Auto-generated template for color"""
    embed = fancy_embed(title='/color', description='This is a template response for color. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='qrcode', description='Crystal Clouds command: qrcode')
async def qrcode(self, interaction: discord.Interaction):
    """Auto-generated template for qrcode"""
    embed = fancy_embed(title='/qrcode', description='This is a template response for qrcode. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='shorten', description='Crystal Clouds command: shorten')
async def shorten(self, interaction: discord.Interaction):
    """Auto-generated template for shorten"""
    embed = fancy_embed(title='/shorten', description='This is a template response for shorten. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='define', description='Crystal Clouds command: define')
async def define(self, interaction: discord.Interaction):
    """Auto-generated template for define"""
    embed = fancy_embed(title='/define', description='This is a template response for define. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='time', description='Crystal Clouds command: time')
async def time(self, interaction: discord.Interaction):
    """Auto-generated template for time"""
    embed = fancy_embed(title='/time', description='This is a template response for time. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='timezone', description='Crystal Clouds command: timezone')
async def timezone(self, interaction: discord.Interaction):
    """Auto-generated template for timezone"""
    embed = fancy_embed(title='/timezone', description='This is a template response for timezone. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='calc', description='Crystal Clouds command: calc')
async def calc(self, interaction: discord.Interaction):
    """Auto-generated template for calc"""
    embed = fancy_embed(title='/calc', description='This is a template response for calc. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='translate', description='Crystal Clouds command: translate')
async def translate(self, interaction: discord.Interaction):
    """Auto-generated template for translate"""
    embed = fancy_embed(title='/translate', description='This is a template response for translate. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='emoji', description='Crystal Clouds command: emoji')
async def emoji(self, interaction: discord.Interaction):
    """Auto-generated template for emoji"""
    embed = fancy_embed(title='/emoji', description='This is a template response for emoji. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='sticker', description='Crystal Clouds command: sticker')
async def sticker(self, interaction: discord.Interaction):
    """Auto-generated template for sticker"""
    embed = fancy_embed(title='/sticker', description='This is a template response for sticker. Customize in cogs.')
    await interaction.response.send_message(embed=embed)



async def setup(bot):
    await bot.add_cog(UtilityCog(bot))
