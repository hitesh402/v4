import discord
from discord import app_commands
from discord.ext import commands
from utils.embed_helper import fancy_embed

class DeveloperCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

@app_commands.command(name='eval', description='Crystal Clouds command: eval')
async def eval(self, interaction: discord.Interaction):
    """Auto-generated template for eval"""
    embed = fancy_embed(title='/eval', description='This is a template response for eval. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='eval2', description='Crystal Clouds command: eval2')
async def eval2(self, interaction: discord.Interaction):
    """Auto-generated template for eval2"""
    embed = fancy_embed(title='/eval2', description='This is a template response for eval2. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='devsay', description='Crystal Clouds command: devsay')
async def devsay(self, interaction: discord.Interaction):
    """Auto-generated template for devsay"""
    embed = fancy_embed(title='/devsay', description='This is a template response for devsay. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='blacklist-add', description='Crystal Clouds command: blacklist-add')
async def blacklist_add(self, interaction: discord.Interaction):
    """Auto-generated template for blacklist-add"""
    embed = fancy_embed(title='/blacklist-add', description='This is a template response for blacklist-add. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='blacklist-remove', description='Crystal Clouds command: blacklist-remove')
async def blacklist_remove(self, interaction: discord.Interaction):
    """Auto-generated template for blacklist-remove"""
    embed = fancy_embed(title='/blacklist-remove', description='This is a template response for blacklist-remove. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='whitelist-add', description='Crystal Clouds command: whitelist-add')
async def whitelist_add(self, interaction: discord.Interaction):
    """Auto-generated template for whitelist-add"""
    embed = fancy_embed(title='/whitelist-add', description='This is a template response for whitelist-add. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='whitelist-remove', description='Crystal Clouds command: whitelist-remove')
async def whitelist_remove(self, interaction: discord.Interaction):
    """Auto-generated template for whitelist-remove"""
    embed = fancy_embed(title='/whitelist-remove', description='This is a template response for whitelist-remove. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='reload2', description='Crystal Clouds command: reload2')
async def reload2(self, interaction: discord.Interaction):
    """Auto-generated template for reload2"""
    embed = fancy_embed(title='/reload2', description='This is a template response for reload2. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='restart2', description='Crystal Clouds command: restart2')
async def restart2(self, interaction: discord.Interaction):
    """Auto-generated template for restart2"""
    embed = fancy_embed(title='/restart2', description='This is a template response for restart2. Customize in cogs.')
    await interaction.response.send_message(embed=embed)



async def setup(bot):
    await bot.add_cog(DeveloperCog(bot))
