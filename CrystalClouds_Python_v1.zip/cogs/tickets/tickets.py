import discord
from discord import app_commands
from discord.ext import commands
from utils.embed_helper import fancy_embed

class TicketsCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

@app_commands.command(name='ticket-create', description='Crystal Clouds command: ticket-create')
async def ticket_create(self, interaction: discord.Interaction):
    """Auto-generated template for ticket-create"""
    embed = fancy_embed(title='/ticket-create', description='This is a template response for ticket-create. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='ticket-close', description='Crystal Clouds command: ticket-close')
async def ticket_close(self, interaction: discord.Interaction):
    """Auto-generated template for ticket-close"""
    embed = fancy_embed(title='/ticket-close', description='This is a template response for ticket-close. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='ticket-add', description='Crystal Clouds command: ticket-add')
async def ticket_add(self, interaction: discord.Interaction):
    """Auto-generated template for ticket-add"""
    embed = fancy_embed(title='/ticket-add', description='This is a template response for ticket-add. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='ticket-remove', description='Crystal Clouds command: ticket-remove')
async def ticket_remove(self, interaction: discord.Interaction):
    """Auto-generated template for ticket-remove"""
    embed = fancy_embed(title='/ticket-remove', description='This is a template response for ticket-remove. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='ticket-rename', description='Crystal Clouds command: ticket-rename')
async def ticket_rename(self, interaction: discord.Interaction):
    """Auto-generated template for ticket-rename"""
    embed = fancy_embed(title='/ticket-rename', description='This is a template response for ticket-rename. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='ticket-reopen', description='Crystal Clouds command: ticket-reopen')
async def ticket_reopen(self, interaction: discord.Interaction):
    """Auto-generated template for ticket-reopen"""
    embed = fancy_embed(title='/ticket-reopen', description='This is a template response for ticket-reopen. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='suggest', description='Crystal Clouds command: suggest')
async def suggest(self, interaction: discord.Interaction):
    """Auto-generated template for suggest"""
    embed = fancy_embed(title='/suggest', description='This is a template response for suggest. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='suggest-list', description='Crystal Clouds command: suggest-list')
async def suggest_list(self, interaction: discord.Interaction):
    """Auto-generated template for suggest-list"""
    embed = fancy_embed(title='/suggest-list', description='This is a template response for suggest-list. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='suggest-approve', description='Crystal Clouds command: suggest-approve')
async def suggest_approve(self, interaction: discord.Interaction):
    """Auto-generated template for suggest-approve"""
    embed = fancy_embed(title='/suggest-approve', description='This is a template response for suggest-approve. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='suggest-deny', description='Crystal Clouds command: suggest-deny')
async def suggest_deny(self, interaction: discord.Interaction):
    """Auto-generated template for suggest-deny"""
    embed = fancy_embed(title='/suggest-deny', description='This is a template response for suggest-deny. Customize in cogs.')
    await interaction.response.send_message(embed=embed)



async def setup(bot):
    await bot.add_cog(TicketsCog(bot))
