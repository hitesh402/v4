import discord
from discord.ext import commands
from utils.embed_helper import fancy_embed
import os
from dotenv import load_dotenv
load_dotenv()

class WelcomeCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member):
        try:
            ch_id = int(os.getenv('WELCOME_CHANNEL'))
            ch = member.guild.get_channel(ch_id)
            if not ch:
                return
            now = discord.utils.format_dt(discord.utils.utcnow(), style='F')
            inviter = 'Unknown'
            invite_count = '0'
            content = f"""╭ ・ ⌬ ・{member.mention} joined.
●▬▬▬▬▬▬▬▬๑۩✰۩๑▬▬▬▬▬▬▬▬●
✰・Member Joined At {now}
✰・Invited by {inviter}
✰・They have now {invite_count} invites
●▬▬▬▬▬▬▬▬๑۩✰۩๑▬▬▬▬▬▬▬▬●
╰ ・ ⌬ ・crystalclouds │ BEST AND BUDGET FRIENDLY HOSTING has now {member.guild.member_count} members"""
            embed = fancy_embed(title=f"{member.display_name} joined", description=content)
            await ch.send(embed=embed)
            log_id = os.getenv('LOGS_CHANNEL')
            if log_id:
                log_ch = member.guild.get_channel(int(log_id))
                if log_ch:
                    await log_ch.send(embed=embed)
        except Exception as e:
            print('Welcome error:', e)

async def setup(bot):
    await bot.add_cog(WelcomeCog(bot))
