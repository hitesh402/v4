import discord
from discord import app_commands
from discord.ext import commands
from utils.embed_helper import fancy_embed

class MusicCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

@app_commands.command(name='play', description='Crystal Clouds command: play')
async def play(self, interaction: discord.Interaction, query: str = None):
    """Auto-generated template for play"""
    embed = fancy_embed(title='/play', description='This is a template response for play. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='pause', description='Crystal Clouds command: pause')
async def pause(self, interaction: discord.Interaction):
    """Auto-generated template for pause"""
    embed = fancy_embed(title='/pause', description='This is a template response for pause. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='resume', description='Crystal Clouds command: resume')
async def resume(self, interaction: discord.Interaction):
    """Auto-generated template for resume"""
    embed = fancy_embed(title='/resume', description='This is a template response for resume. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='skip', description='Crystal Clouds command: skip')
async def skip(self, interaction: discord.Interaction):
    """Auto-generated template for skip"""
    embed = fancy_embed(title='/skip', description='This is a template response for skip. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='stop', description='Crystal Clouds command: stop')
async def stop(self, interaction: discord.Interaction):
    """Auto-generated template for stop"""
    embed = fancy_embed(title='/stop', description='This is a template response for stop. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='queue', description='Crystal Clouds command: queue')
async def queue(self, interaction: discord.Interaction):
    """Auto-generated template for queue"""
    embed = fancy_embed(title='/queue', description='This is a template response for queue. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='nowplaying', description='Crystal Clouds command: nowplaying')
async def nowplaying(self, interaction: discord.Interaction):
    """Auto-generated template for nowplaying"""
    embed = fancy_embed(title='/nowplaying', description='This is a template response for nowplaying. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='volume', description='Crystal Clouds command: volume')
async def volume(self, interaction: discord.Interaction):
    """Auto-generated template for volume"""
    embed = fancy_embed(title='/volume', description='This is a template response for volume. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='lyrics', description='Crystal Clouds command: lyrics')
async def lyrics(self, interaction: discord.Interaction):
    """Auto-generated template for lyrics"""
    embed = fancy_embed(title='/lyrics', description='This is a template response for lyrics. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='disconnect', description='Crystal Clouds command: disconnect')
async def disconnect(self, interaction: discord.Interaction):
    """Auto-generated template for disconnect"""
    embed = fancy_embed(title='/disconnect', description='This is a template response for disconnect. Customize in cogs.')
    await interaction.response.send_message(embed=embed)



async def setup(bot):
    await bot.add_cog(MusicCog(bot))
