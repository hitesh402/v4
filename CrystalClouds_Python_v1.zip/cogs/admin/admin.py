import discord
from discord import app_commands
from discord.ext import commands
from utils.embed_helper import fancy_embed

class AdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

@app_commands.command(name='set-autorole', description='Crystal Clouds command: set-autorole')
async def set_autorole(self, interaction: discord.Interaction):
    """Auto-generated template for set-autorole"""
    embed = fancy_embed(title='/set-autorole', description='This is a template response for set-autorole. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='reactionrole', description='Crystal Clouds command: reactionrole')
async def reactionrole(self, interaction: discord.Interaction):
    """Auto-generated template for reactionrole"""
    embed = fancy_embed(title='/reactionrole', description='This is a template response for reactionrole. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='set-prefix', description='Crystal Clouds command: set-prefix')
async def set_prefix(self, interaction: discord.Interaction):
    """Auto-generated template for set-prefix"""
    embed = fancy_embed(title='/set-prefix', description='This is a template response for set-prefix. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='set-welcome', description='Crystal Clouds command: set-welcome')
async def set_welcome(self, interaction: discord.Interaction):
    """Auto-generated template for set-welcome"""
    embed = fancy_embed(title='/set-welcome', description='This is a template response for set-welcome. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='set-leave', description='Crystal Clouds command: set-leave')
async def set_leave(self, interaction: discord.Interaction):
    """Auto-generated template for set-leave"""
    embed = fancy_embed(title='/set-leave', description='This is a template response for set-leave. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='set-logs', description='Crystal Clouds command: set-logs')
async def set_logs(self, interaction: discord.Interaction):
    """Auto-generated template for set-logs"""
    embed = fancy_embed(title='/set-logs', description='This is a template response for set-logs. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='setup', description='Crystal Clouds command: setup')
async def setup(self, interaction: discord.Interaction):
    """Auto-generated template for setup"""
    embed = fancy_embed(title='/setup', description='This is a template response for setup. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='reset-settings', description='Crystal Clouds command: reset-settings')
async def reset_settings(self, interaction: discord.Interaction):
    """Auto-generated template for reset-settings"""
    embed = fancy_embed(title='/reset-settings', description='This is a template response for reset-settings. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='restart', description='Crystal Clouds command: restart')
async def restart(self, interaction: discord.Interaction):
    """Auto-generated template for restart"""
    embed = fancy_embed(title='/restart', description='This is a template response for restart. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='shutdown', description='Crystal Clouds command: shutdown')
async def shutdown(self, interaction: discord.Interaction):
    """Auto-generated template for shutdown"""
    embed = fancy_embed(title='/shutdown', description='This is a template response for shutdown. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='reload', description='Crystal Clouds command: reload')
async def reload(self, interaction: discord.Interaction):
    """Auto-generated template for reload"""
    embed = fancy_embed(title='/reload', description='This is a template response for reload. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='backup-create', description='Crystal Clouds command: backup-create')
async def backup_create(self, interaction: discord.Interaction):
    """Auto-generated template for backup-create"""
    embed = fancy_embed(title='/backup-create', description='This is a template response for backup-create. Customize in cogs.')
    await interaction.response.send_message(embed=embed)

@app_commands.command(name='backup-load', description='Crystal Clouds command: backup-load')
async def backup_load(self, interaction: discord.Interaction):
    """Auto-generated template for backup-load"""
    embed = fancy_embed(title='/backup-load', description='This is a template response for backup-load. Customize in cogs.')
    await interaction.response.send_message(embed=embed)



async def setup(bot):
    await bot.add_cog(AdminCog(bot))
