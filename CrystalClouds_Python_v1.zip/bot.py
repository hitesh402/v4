import os
import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv('DISCORD_TOKEN')
GUILD_ID = os.getenv('GUILD_ID')  # optional for guild-only sync
PREFIX = os.getenv('PREFIX', '!')

intents = discord.Intents.default()
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix=PREFIX, intents=intents)

COGS = [
    'cogs.admin.admin',
    'cogs.ai.ai',
    'cogs.developer.dev',
    'cogs.fun.fun',
    'cogs.moderation.mod',
    'cogs.music.music',
    'cogs.utility.utility',
    'cogs.tickets.tickets',
    'cogs.economy.economy',
    'cogs.welcome.welcome'
]

@bot.event
async def on_ready():
    print(f'✅ Logged in as {bot.user} (ID: {bot.user.id})')
    for cog in COGS:
        try:
            await bot.load_extension(cog)
            print(f'Loaded cog: {cog}')
        except Exception as e:
            print(f'Failed to load {cog}:', e)
    try:
        if GUILD_ID:
            gid = int(GUILD_ID)
            await bot.tree.sync(guild=discord.Object(id=gid))
            print('✅ Synced commands to guild', gid)
        else:
            await bot.tree.sync()
            print('✅ Synced global commands')
    except Exception as e:
        print('Sync error:', e)

if __name__ == '__main__':
    bot.run(TOKEN)
