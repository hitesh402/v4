import discord, os
def fancy_embed(title='', description='', color=None):
    try:
        color_val = int(os.getenv('EMBED_COLOR', '0x00FFFF'), 16)
    except:
        color_val = 0x00FFFF
    e = discord.Embed(title=title, description=description, color=color_val)
    e.set_footer(text='crystalclouds • 2025')
    return e
