CrystalClouds Python v1
======================

What's included:
- bot.py: main bot loader (loads cogs and syncs app commands)
- cogs/: 10+ folders with 130+ command templates (slash commands)
- requirements.txt: pip install -r requirements.txt
- .env.example: copy to .env and set your keys & IDs

Quick start:
1. python3 -m pip install -r requirements.txt
2. Install ffmpeg for music: apt install ffmpeg -y
3. Fill .env with your DISCORD_TOKEN and IDs
4. Run: python3 bot.py

Notes:
- Music commands require system ffmpeg + yt-dlp.
- AI commands are placeholders; set OPENAI_API_KEY to use.
- All command files are templates responding with a simple embed — implement logic as needed.
